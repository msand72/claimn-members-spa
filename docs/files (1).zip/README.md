# CLAIM'N Design System — Drop-in Files

## What's here

```
src/
  tokens/
    pillars.ts          ← Pillar token map (colors, names, metadata)
    tokens.ts           ← CSS custom properties + Tailwind config additions
  components/
    icons/
      PillarIcon.tsx    ← 5 pillar SVG icons at 32px + 80px
      PillarBadge.tsx   ← PillarBadge, PillarDot, pillarLeftBorder
    ui/
      StatCardVisuals.tsx ← 6 stat card SVG visualizations
      HubHeroArt.tsx    ← Hub page hero compass illustration
  index.ts              ← Barrel exports
```

---

## Step 1 — Replace pillar color map

In all three repos (`claimn-members-spa`, `admin-spa`, `claimn-web`), find the existing `PILLARS` constant and replace with the one from `tokens/pillars.ts`.

**Old (broken — Identity and Mission both koppar, Connection invisible):**
```typescript
PILLARS = {
  identity:   { color: 'koppar',   icon: 'Compass' },
  emotional:  { color: 'oliv',     icon: 'Brain'   },
  physical:   { color: 'jordbrun', icon: 'Heart'   },
  connection: { color: 'charcoal', icon: 'Users'   },
  mission:    { color: 'koppar',   icon: 'Target'  },
}
```

**New (5 distinct colors, all accessible on dark + light):**
```typescript
identity:   #B87333  // Koppar
emotional:  #A1B1C6  // Dimmig Blågrå
physical:   #6B8E6F  // Skogsgrön
connection: #8A7264  // Jordbrun lightened
mission:    #6E8077  // Oliv lightened
```

---

## Step 2 — Add CSS tokens to globals.css

Copy the CSS string from `tokens/tokens.ts` into your `globals.css`.
Critical: the `--font-display`, `--font-serif`, `--font-body` declarations
reference Neutraface 2, Playfair Display, and Lato — already loaded in all repos.

Also add to `tailwind.config.ts`:
```typescript
import { TAILWIND_TOKENS } from './src/tokens/tokens'

export default {
  theme: {
    extend: {
      colors:     TAILWIND_TOKENS.colors,
      fontFamily: TAILWIND_TOKENS.fontFamily,
    }
  }
}
```

---

## Step 3 — Replace Lucide pillar icons with PillarIcon

Find all instances of the old generic icons:
- `Compass` → `<PillarIcon pillar="identity" size={32} />`
- `Brain`   → `<PillarIcon pillar="emotional" size={32} />`
- `Heart`   → `<PillarIcon pillar="physical" size={32} />`
- `Users`   → `<PillarIcon pillar="connection" size={32} />`
- `Target`  → `<PillarIcon pillar="mission" size={32} />`

For card headers / section markers use `size={80}` with `className="absolute top-4 right-4 opacity-[0.12] rotate-12"`.

---

## Step 4 — Add pillar badge to every goal/KPI/protocol card

Since `pillar_id` is becoming required everywhere:

```tsx
// On every goal card, KPI row, protocol card:
import { PillarBadge, pillarLeftBorder } from '@/design-system'

<GlassCard
  style={pillarLeftBorder(goal.pillar_id)}
  leftBorder={false}  // We handle the border ourselves
>
  <PillarBadge pillar={goal.pillar_id} size="sm" />
  ...
</GlassCard>
```

---

## Step 5 — Drop stat card visuals into GlassStatsCard

```tsx
import { StreakVisual, GoalsVisual, VitalityVisual } from '@/design-system'

// In GlassStatsCard render:
<div className="mt-3">
  {statType === 'streak'    && <StreakVisual days={streak} />}
  {statType === 'goals'     && <GoalsVisual activeCount={4} onTrackCount={2} />}
  {statType === 'vitality'  && <VitalityVisual scores={pillarScores} />}
  {statType === 'adherence' && <AdherenceVisual percent={adherencePercent} />}
  {statType === 'days'      && <DaysActiveVisual />}
  {statType === 'connections' && <ConnectionsVisual intimate={5} close={7} />}
</div>
```

---

## Step 6 — Hub page hero

```tsx
import { HubHeroArt } from '@/design-system'

<div className="hero-strip relative h-[200px] overflow-hidden rounded-2xl">
  <HubHeroArt className="absolute right-0 top-0 bottom-0 w-[380px] opacity-70" />
  <div className="relative z-10 h-full flex flex-col justify-center px-8">
    <p className="text-koppar font-display text-xs tracking-[0.18em] uppercase mb-2">
      Day {dayCount} · {date}
    </p>
    <h2 className="font-display font-bold text-2xl text-primary">
      Good morning, {firstName}
    </h2>
    <p className="font-serif italic text-sm text-secondary mt-1">
      {nextProtocol}
    </p>
  </div>
</div>
```

---

## Text contrast values

The spec's original `--text-secondary` and `--text-muted` values fail WCAG AA.
Use these instead:

| Token            | Dark                        | Light                      |
|------------------|-----------------------------|----------------------------|
| `--text-primary` | `#F9F7F4`                   | `#1C1C1E`                  |
| `--text-secondary` | `rgba(249,247,244,0.80)` | `rgba(28,28,30,0.78)`      |
| `--text-muted`   | `rgba(249,247,244,0.55)`    | `rgba(28,28,30,0.54)`      |

---

## Font stack

Already loaded in all repos. Reference via CSS variables:

```css
font-family: var(--font-display); /* Neutraface 2 Display, Montserrat fallback */
font-family: var(--font-serif);   /* Playfair Display, Georgia fallback */
font-family: var(--font-body);    /* Lato, system-ui fallback */
```
