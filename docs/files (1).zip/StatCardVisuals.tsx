/**
 * StatCardVisuals
 * SVG visualizations for the 6 GlassStatsCard components on the Hub page.
 * Each lives in the visual slot below the number (height: 44-52px).
 *
 * Usage inside GlassStatsCard:
 *   <StreakVisual />
 *   <GoalsVisual activeCount={4} onTrackCount={2} />
 *   <VitalityVisual scores={pillarScores} />
 */

import React from 'react'
import { type PillarId } from '../../tokens/pillars'
import { PILLARS, PILLAR_ORDER } from '../../tokens/pillars'

/* Shared viewBox width — always 200, height varies per card */
const VB_W = 200

/* ─── STREAK ─────────────────────────────────────────── */
export const StreakVisual: React.FC<{ days?: number }> = ({ days = 23 }) => (
  <svg width="100%" height="44" viewBox={`0 0 ${VB_W} 44`} fill="none" preserveAspectRatio="xMidYMid meet">
    {/* Ascending bars — each bar one day, rightmost = today */}
    <rect x="0"  y="30" width="8" height="14" rx="1.5" fill="#B87333" opacity="0.22"/>
    <rect x="11" y="25" width="8" height="19" rx="1.5" fill="#B87333" opacity="0.32"/>
    <rect x="22" y="19" width="8" height="25" rx="1.5" fill="#B87333" opacity="0.44"/>
    <rect x="33" y="13" width="8" height="31" rx="1.5" fill="#B87333" opacity="0.58"/>
    <rect x="44" y="7"  width="8" height="37" rx="1.5" fill="#B87333" opacity="0.74"/>
    <rect x="55" y="2"  width="8" height="42" rx="1.5" fill="#B87333" opacity="0.90"/>
    {/* Trajectory */}
    <path d="M4 35 Q28 20 59 4" stroke="#B87333" strokeWidth="0.9" strokeDasharray="2 2" fill="none" opacity="0.55"/>
    {/* Days label */}
    <text x="80" y="28" fontFamily="var(--font-display)" fontSize="10" fontWeight="700" fill="currentColor" opacity="0.22" letterSpacing="0.10em">DAYS</text>
  </svg>
)

/* ─── ACTIVE GOALS ───────────────────────────────────── */
export const GoalsVisual: React.FC<{
  activeCount?: number
  onTrackCount?: number
}> = ({ activeCount = 4, onTrackCount = 2 }) => (
  <svg width="100%" height="44" viewBox={`0 0 ${VB_W} 44`} fill="none" preserveAspectRatio="xMidYMid meet">
    {Array.from({ length: activeCount }).map((_, i) => {
      const x = 16 + i * 32
      const onTrack = i < onTrackCount
      return (
        <g key={i} transform={`translate(${x},22)`}>
          <circle r="13" stroke={onTrack ? '#B87333' : 'currentColor'} strokeWidth="1.8" opacity={onTrack ? 1 : 0.28}/>
          <circle r="8"  stroke={onTrack ? '#B87333' : 'currentColor'} strokeWidth="1.2" opacity={onTrack ? 0.5 : 0.18}/>
          {onTrack
            ? <circle r="3.5" fill="#B87333" opacity="0.82"/>
            : <circle r="3.5" stroke="currentColor" strokeWidth="1" opacity="0.20" fill="none"/>
          }
        </g>
      )
    })}
    <text x="140" y="26" fontFamily="var(--font-display)" fontSize="9" fill="currentColor" opacity="0.28">on track</text>
  </svg>
)

/* ─── VITALITY SCORE (RADAR) ─────────────────────────── */
interface PillarScore { pillar: PillarId; score: number }

export const VitalityVisual: React.FC<{ scores?: PillarScore[] }> = ({ scores }) => {
  // Default scores if none provided
  const defaultScores: PillarScore[] = PILLAR_ORDER.map((id) => ({ pillar: id, score: 0.82 }))
  const data = scores ?? defaultScores

  // Pentagon geometry — 5 points at 72° intervals, starting from top
  const cx = 30, cy = 26, r = 20
  const angles = [270, 342, 54, 126, 198] // top, top-right, bottom-right, bottom-left, top-left

  const point = (angle: number, radius: number) => ({
    x: cx + radius * Math.cos((angle * Math.PI) / 180),
    y: cy + radius * Math.sin((angle * Math.PI) / 180),
  })

  const outerPoints = angles.map((a) => point(a, r))
  const dataPoints  = angles.map((a, i) => point(a, r * (data[i]?.score ?? 0.8)))

  const toPolygon = (pts: { x: number; y: number }[]) =>
    pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ')

  return (
    <svg width="100%" height="50" viewBox={`0 0 ${VB_W} 50`} fill="none" preserveAspectRatio="xMidYMid meet">
      {/* Outer ring ghost */}
      <polygon points={toPolygon(outerPoints)} stroke="currentColor" strokeWidth="0.6" opacity="0.16" fill="none"/>
      {/* Mid ring ghost — 60% */}
      <polygon
        points={toPolygon(angles.map((a) => point(a, r * 0.6)))}
        stroke="currentColor" strokeWidth="0.5" opacity="0.10" fill="none"
      />
      {/* Spokes */}
      {angles.map((a, i) => {
        const p = outerPoints[i]
        return <line key={i} x1={cx} y1={cy} x2={p.x} y2={p.y} stroke="currentColor" strokeWidth="0.5" opacity="0.12"/>
      })}
      {/* Data polygon */}
      <polygon points={toPolygon(dataPoints)} stroke="#6B8E6F" strokeWidth="1.6" fill="rgba(107,142,111,0.10)"/>
      {/* Pillar dots in accent colors */}
      {data.map((d, i) => {
        const p = dataPoints[i]
        return <circle key={i} cx={p.x} cy={p.y} r="2.5" fill={PILLARS[d.pillar].color}/>
      })}
      {/* Labels */}
      <text x="68" y="18" fontFamily="var(--font-display)" fontSize="10" fill="#6B8E6F" fontWeight="700" opacity="0.85">Balanced</text>
      <text x="68" y="30" fontFamily="var(--font-body)" fontSize="10" fill="currentColor" opacity="0.35">5 pillars</text>
      {/* Pillar color legend strip */}
      {PILLAR_ORDER.map((id, i) => (
        <rect key={id} x={68 + i * 12} y="36" width="8" height="8" rx="2" fill={PILLARS[id].color}/>
      ))}
    </svg>
  )
}

/* ─── PROTOCOL ADHERENCE ─────────────────────────────── */
export const AdherenceVisual: React.FC<{ percent?: number }> = ({ percent = 91 }) => {
  const circumference = 2 * Math.PI * 18
  const dashArray = `${(percent / 100) * circumference} ${(1 - percent / 100) * circumference}`
  const dashOffset = circumference * 0.25 // start from top

  return (
    <svg width="100%" height="44" viewBox={`0 0 ${VB_W} 44`} fill="none" preserveAspectRatio="xMidYMid meet">
      {/* Arc ring */}
      <circle cx="28" cy="24" r="18" stroke="currentColor" strokeWidth="1" opacity="0.12"/>
      <circle
        cx="28" cy="24" r="18"
        stroke="#A1B1C6" strokeWidth="2.8"
        strokeDasharray={dashArray}
        strokeDashoffset={dashOffset}
        strokeLinecap="round" fill="none"
      />
      <text x="28" y="28" textAnchor="middle" fontFamily="var(--font-display)" fontWeight="700" fontSize="9" fill="currentColor" opacity="0.72">
        {percent}%
      </text>
      {/* 30-day bars */}
      {[20, 24, 18, 28, 20, 22, 14, 28, 18, 20, 10].map((h, i) => (
        <rect
          key={i}
          x={56 + i * 13}
          y={36 - h}
          width="9"
          height={h}
          rx="1.5"
          fill={h === 28 ? 'currentColor' : '#A1B1C6'}
          opacity={h === 28 ? 0.18 : 0.65 + i * 0.02}
        />
      ))}
    </svg>
  )
}

/* ─── DAYS ACTIVE (HEAT MAP) ─────────────────────────── */
export const DaysActiveVisual: React.FC<{
  activeDays?: boolean[][]
}> = ({ activeDays }) => {
  // Default: 78% active — 3 rows × 7 cols
  const defaultGrid = [
    [true,  true,  true,  false, true,  true,  true ],
    [true,  false, true,  true,  true,  true,  false],
    [true,  true,  true,  false, true,  true,  true ],
  ]
  const grid = activeDays ?? defaultGrid

  return (
    <svg width="100%" height="44" viewBox={`0 0 ${VB_W} 44`} fill="none" preserveAspectRatio="xMidYMid meet">
      {grid.map((row, r) =>
        row.map((active, c) => (
          <rect
            key={`${r}-${c}`}
            x={c * 14}
            y={2 + r * 14}
            width="12"
            height="12"
            rx="2"
            fill={active ? '#B87333' : 'currentColor'}
            opacity={active ? 0.72 + Math.random() * 0.18 : 0.10}
          />
        ))
      )}
      <text x="108" y="18" fontFamily="var(--font-display)" fontSize="10" fill="currentColor" opacity="0.30">Active</text>
      <text x="108" y="32" fontFamily="var(--font-display)" fontWeight="700" fontSize="14" fill="currentColor" opacity="0.55">78%</text>
    </svg>
  )
}

/* ─── BROTHERHOOD CONNECTIONS ────────────────────────── */
export const ConnectionsVisual: React.FC<{
  intimate?: number
  close?: number
}> = ({ intimate = 5, close = 7 }) => (
  <svg width="100%" height="44" viewBox={`0 0 ${VB_W} 44`} fill="none" preserveAspectRatio="xMidYMid meet">
    <g transform="translate(26,22)">
      {/* Rings */}
      <circle r="20" stroke="currentColor" strokeWidth="0.6" opacity="0.10"/>
      <circle r="13" stroke="currentColor" strokeWidth="0.8" opacity="0.18"/>
      <circle r="7"  stroke="#8A7264"     strokeWidth="1.6" fill="rgba(138,114,100,0.08)"/>
      {/* Inner 5 dots — pentagonal */}
      {[270, 342, 54, 126, 198].map((angle, i) => {
        const x = 7 * Math.cos((angle * Math.PI) / 180)
        const y = 7 * Math.sin((angle * Math.PI) / 180)
        return <circle key={i} cx={x} cy={y} r="1.8" fill="#8A7264" opacity="0.85"/>
      })}
      {/* Middle ring dots */}
      {[270, 315, 0, 45, 90, 135, 180, 225].slice(0, close).map((angle, i) => {
        const x = 13 * Math.cos((angle * Math.PI) / 180)
        const y = 13 * Math.sin((angle * Math.PI) / 180)
        return <circle key={i} cx={x} cy={y} r="1.4" fill="currentColor" opacity="0.22"/>
      })}
    </g>
    <text x="58" y="18" fontFamily="var(--font-display)" fontSize="9" fill="#8A7264" opacity="0.60" fontWeight="700">{intimate} intimate</text>
    <text x="58" y="30" fontFamily="var(--font-body)"    fontSize="9" fill="currentColor" opacity="0.30">{close} close</text>
  </svg>
)
