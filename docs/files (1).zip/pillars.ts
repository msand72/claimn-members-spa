/**
 * CLAIM'N Pillar Token System
 * Single source of truth — replaces the broken PILLARS config in the current spec.
 *
 * Key changes from old spec:
 *  - Identity and Mission no longer share koppar
 *  - Connection no longer uses kalkvit/80 (invisible in light mode)
 *  - All five colors tested on #0A0A0B (dark) and #F9F7F4 (light) at 12px badge size
 *  - Colors are distinct enough to navigate by, not just aesthetically varied
 */

export type PillarId =
  | 'identity'
  | 'emotional'
  | 'physical'
  | 'connection'
  | 'mission'

export interface PillarToken {
  id: PillarId
  name: string
  shortName: string
  /** Hex — hardcoded, tested on both dark and light backgrounds */
  color: string
  /** rgba fill for backgrounds at 12% opacity */
  colorLo: string
  /** rgba border at 28% opacity */
  colorBorder: string
  /** Brief geometric brief — what the icon represents */
  brief: string
  /** Csikszentmihályi / Dunbar / framework reference */
  reference: string
}

export const PILLARS: Record<PillarId, PillarToken> = {
  identity: {
    id: 'identity',
    name: 'Identity & Purpose',
    shortName: 'Identity',
    color: '#B87333',
    colorLo: 'rgba(184,115,51,0.12)',
    colorBorder: 'rgba(184,115,51,0.28)',
    brief: 'Foundation grid + direction vector',
    reference: 'The architecture underneath everything else',
  },
  emotional: {
    id: 'emotional',
    name: 'Emotional & Mental',
    shortName: 'Mental',
    color: '#A1B1C6',
    colorLo: 'rgba(161,177,198,0.12)',
    colorBorder: 'rgba(161,177,198,0.28)',
    brief: 'Pressure-to-output conversion node',
    reference: 'Stress-to-fuel conversion using male-specific patterns',
  },
  physical: {
    id: 'physical',
    name: 'Physical & Vital',
    shortName: 'Physical',
    color: '#6B8E6F',
    colorLo: 'rgba(107,142,111,0.12)',
    colorBorder: 'rgba(107,142,111,0.28)',
    brief: 'Ascending performance bars + trajectory arc',
    reference: 'Capability that holds at 70, not just 35',
  },
  connection: {
    id: 'connection',
    name: 'Connection & Leadership',
    shortName: 'Connection',
    color: '#8A7264',
    colorLo: 'rgba(138,114,100,0.12)',
    colorBorder: 'rgba(138,114,100,0.28)',
    brief: 'Dunbar rings 5·15·150 + parallel vectors',
    reference: '23% lower cortisol from shoulder-to-shoulder bonding',
  },
  mission: {
    id: 'mission',
    name: 'Mission & Mastery',
    shortName: 'Mission',
    color: '#6E8077',
    colorLo: 'rgba(110,128,119,0.12)',
    colorBorder: 'rgba(110,128,119,0.28)',
    brief: 'Flow zone band — challenge·skill axes',
    reference: 'Csikszentmihályi: 200-500% performance in flow',
  },
}

export const PILLAR_ORDER: PillarId[] = [
  'identity',
  'emotional',
  'physical',
  'connection',
  'mission',
]

/** Convenience — get pillar by id with type safety */
export const getPillar = (id: PillarId): PillarToken => PILLARS[id]

/** All pillars as array in display order */
export const getPillars = (): PillarToken[] => PILLAR_ORDER.map((id) => PILLARS[id])
