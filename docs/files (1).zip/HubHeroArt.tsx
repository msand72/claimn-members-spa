/**
 * HubHeroArt
 * The compass hero illustration for the Hub dashboard hero strip.
 * Positioned absolutely right-aligned inside the hero card.
 *
 * Usage:
 *   <div className="hero-strip relative">
 *     <HubHeroArt className="absolute right-0 top-0 bottom-0 w-[380px] opacity-70" />
 *     <div className="relative z-10">...</div>
 *   </div>
 */

import React from 'react'

interface HubHeroArtProps {
  className?: string
}

export const HubHeroArt: React.FC<HubHeroArtProps> = ({ className = '' }) => (
  <svg
    className={className}
    viewBox="0 0 380 200"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    preserveAspectRatio="xMaxYMid meet"
  >
    {/* Outer ghost rings */}
    <circle cx="280" cy="100" r="140" stroke="currentColor" strokeWidth="0.5" opacity="0.07"/>
    <circle cx="280" cy="100" r="110" stroke="currentColor" strokeWidth="0.5" opacity="0.08"/>
    <circle cx="280" cy="100" r="82"  stroke="currentColor" strokeWidth="0.6" opacity="0.10"/>
    {/* Ghost grid lines */}
    <line x1="140" y1="100" x2="380" y2="100" stroke="currentColor" strokeWidth="0.5" opacity="0.08"/>
    <line x1="280" y1="0"   x2="280" y2="200" stroke="currentColor" strokeWidth="0.5" opacity="0.08"/>
    <line x1="182" y1="2"   x2="378" y2="198" stroke="currentColor" strokeWidth="0.4" opacity="0.05"/>
    <line x1="378" y1="2"   x2="182" y2="198" stroke="currentColor" strokeWidth="0.4" opacity="0.05"/>
    {/* Cardinal spokes */}
    <line x1="280" y1="18"  x2="280" y2="60"  stroke="currentColor" strokeWidth="1.4" opacity="0.55" strokeLinecap="round"/>
    <line x1="280" y1="140" x2="280" y2="182" stroke="currentColor" strokeWidth="1.4" opacity="0.55" strokeLinecap="round"/>
    <line x1="198" y1="100" x2="240" y2="100" stroke="currentColor" strokeWidth="1.4" opacity="0.55" strokeLinecap="round"/>
    <line x1="320" y1="100" x2="362" y2="100" stroke="currentColor" strokeWidth="1.4" opacity="0.55" strokeLinecap="round"/>
    {/* Diagonal spokes */}
    <line x1="221" y1="41"  x2="247" y2="67"  stroke="currentColor" strokeWidth="1.0" opacity="0.30" strokeLinecap="round"/>
    <line x1="339" y1="41"  x2="313" y2="67"  stroke="currentColor" strokeWidth="1.0" opacity="0.30" strokeLinecap="round"/>
    <line x1="221" y1="159" x2="247" y2="133" stroke="currentColor" strokeWidth="1.0" opacity="0.30" strokeLinecap="round"/>
    <line x1="339" y1="159" x2="313" y2="133" stroke="currentColor" strokeWidth="1.0" opacity="0.30" strokeLinecap="round"/>
    {/* Koppar accent ring */}
    <circle cx="280" cy="100" r="36" stroke="#B87333" strokeWidth="1.5" opacity="0.80"/>
    {/* Inner accent ring */}
    <circle cx="280" cy="100" r="18" stroke="#B87333" strokeWidth="1.0" opacity="0.45"/>
    {/* North arrowhead */}
    <path d="M280 18 L277 26 L280 24 L283 26 Z" fill="#B87333" opacity="0.90"/>
    {/* Cardinal ticks on koppar ring */}
    <line x1="280" y1="64"  x2="280" y2="69"  stroke="#B87333" strokeWidth="1.5" opacity="0.65" strokeLinecap="round"/>
    <line x1="316" y1="100" x2="311" y2="100" stroke="#B87333" strokeWidth="1.5" opacity="0.65" strokeLinecap="round"/>
    <line x1="280" y1="136" x2="280" y2="131" stroke="#B87333" strokeWidth="1.0" opacity="0.40" strokeLinecap="round"/>
    <line x1="244" y1="100" x2="249" y2="100" stroke="#B87333" strokeWidth="1.0" opacity="0.40" strokeLinecap="round"/>
    {/* Center dot */}
    <circle cx="280" cy="100" r="5" fill="#B87333" opacity="0.90"/>
    {/* Corner accent dots */}
    <circle cx="222" cy="42"  r="2" fill="currentColor" opacity="0.20"/>
    <circle cx="338" cy="42"  r="2" fill="currentColor" opacity="0.20"/>
  </svg>
)

export default HubHeroArt
