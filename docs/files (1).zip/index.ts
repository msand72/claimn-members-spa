/**
 * CLAIM'N Design System
 * Entry point — import from here in the app
 *
 * Usage:
 *   import { PillarIcon, PillarBadge, PillarDot, pillarLeftBorder } from '@/design-system'
 *   import { StreakVisual, VitalityVisual, GoalsVisual }             from '@/design-system'
 *   import { HubHeroArt }                                            from '@/design-system'
 *   import { PILLARS, getPillar, getPillars, type PillarId }         from '@/design-system'
 */

// Tokens
export {
  PILLARS,
  PILLAR_ORDER,
  getPillar,
  getPillars,
  type PillarId,
  type PillarToken,
} from './tokens/pillars'

export { CSS_TOKENS, TAILWIND_TOKENS } from './tokens/tokens'

// Icons
export { PillarIcon }   from './components/icons/PillarIcon'
export {
  PillarBadge,
  PillarDot,
  pillarLeftBorder,
} from './components/icons/PillarBadge'

// Stat card visuals
export {
  StreakVisual,
  GoalsVisual,
  VitalityVisual,
  AdherenceVisual,
  DaysActiveVisual,
  ConnectionsVisual,
} from './components/ui/StatCardVisuals'

// Hub
export { HubHeroArt } from './components/ui/HubHeroArt'
