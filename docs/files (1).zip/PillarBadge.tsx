/**
 * PillarBadge
 * Inline pillar identifier — appears on every goal, KPI, and protocol card
 * once pillar_id becomes required.
 *
 * Usage:
 *   <PillarBadge pillar="physical" />
 *   <PillarBadge pillar="mission" size="sm" showIcon={false} />
 */

import React from 'react'
import { type PillarId, getPillar } from '../../tokens/pillars'
import { PillarIcon } from './PillarIcon'

interface PillarBadgeProps {
  pillar: PillarId
  size?: 'sm' | 'md'
  showIcon?: boolean
  className?: string
}

export const PillarBadge: React.FC<PillarBadgeProps> = ({
  pillar,
  size = 'md',
  showIcon = true,
  className = '',
}) => {
  const token = getPillar(pillar)

  const padding = size === 'sm' ? '2px 8px' : '3px 10px'
  const fontSize = size === 'sm' ? '10px' : '11px'
  const iconSize = 16 // always 16px inline

  return (
    <span
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '5px',
        padding,
        borderRadius: '4px',
        background: token.colorLo,
        border: `1px solid ${token.colorBorder}`,
        color: token.color,
        fontSize,
        fontFamily: 'var(--font-display)',
        fontWeight: 700,
        letterSpacing: '0.08em',
        textTransform: 'uppercase',
        lineHeight: 1,
        whiteSpace: 'nowrap',
      }}
    >
      {showIcon && (
        <span style={{ display: 'inline-flex', width: iconSize, height: iconSize, flexShrink: 0 }}>
          {/* Inline micro icon at 16px — scaled down from 32px viewBox */}
          <PillarIcon pillar={pillar} size={32} className="scale-[0.5] origin-top-left" />
        </span>
      )}
      {token.shortName}
    </span>
  )
}

/**
 * PillarLeftBorder
 * The 4px left border accent used on GlassCard when a pillar is present.
 * Returns only the border style — apply to the card's style prop.
 *
 * Usage:
 *   <GlassCard style={pillarLeftBorder('physical')} leftBorder={false}>
 */
export const pillarLeftBorder = (pillar: PillarId): React.CSSProperties => ({
  borderLeft: `3px solid ${getPillar(pillar).color}`,
  borderRadius: '0 20px 20px 0',
})

/**
 * PillarDot
 * Smallest possible pillar indicator — 8px colored dot.
 * Used in dense lists, table rows, timeline items.
 *
 * Usage:
 *   <PillarDot pillar="emotional" />
 */
export const PillarDot: React.FC<{ pillar: PillarId; size?: number }> = ({
  pillar,
  size = 8,
}) => {
  const token = getPillar(pillar)
  return (
    <span
      style={{
        display: 'inline-block',
        width: size,
        height: size,
        borderRadius: '50%',
        background: token.color,
        flexShrink: 0,
      }}
    />
  )
}

export default PillarBadge
