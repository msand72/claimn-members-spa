/**
 * CLAIM'N Design Tokens
 * CSS custom properties for globals.css / tailwind.config
 *
 * Font stack:
 *   Display  → Neutraface 2 Display (already loaded in all repos)
 *   Serif    → Playfair Display
 *   Body/UI  → Lato
 */

/* ─── globals.css additions ─── */
export const CSS_TOKENS = `
/* ── Brand colors (static, never theme-aware) ── */
:root {
  --koppar:        #B87333;
  --koppar-lo:     rgba(184,115,51,0.12);
  --koppar-border: rgba(184,115,51,0.28);
  --jordbrun:      #5E503F;
  --sandbeige:     #E5D9C7;
  --oliv:          #3A4A42;
  --dimblag:       #A1B1C6;
  --kalkvit:       #F9F7F4;
  --charcoal:      #1C1C1E;
  --skogsgron:     #6B8E6F;
  --tegelrod:      #B54A46;
  --brand-amber:   #CC8B3C;

  /* ── Pillar accent colors ── */
  --pillar-identity:   #B87333;
  --pillar-emotional:  #A1B1C6;
  --pillar-physical:   #6B8E6F;
  --pillar-connection: #8A7264;
  --pillar-mission:    #6E8077;

  /* ── Font stacks ── */
  --font-display: 'Neutraface 2 Display', 'Montserrat', sans-serif;
  --font-serif:   'Playfair Display', 'Georgia', serif;
  --font-body:    'Lato', 'system-ui', sans-serif;
}

/* ── Dark theme (default) ── */
[data-theme="dark"], .dark {
  --bg-primary:      #0A0A0B;
  --bg-card:         rgba(255,255,255,0.08);
  --border-color:    rgba(255,255,255,0.15);

  --text-primary:    #F9F7F4;
  --text-secondary:  rgba(249,247,244,0.80);
  --text-muted:      rgba(249,247,244,0.55);

  /* Glass layers */
  --glass-base:      rgba(28,28,30,0.95);
  --glass-elevated:  rgba(28,28,30,0.97);
  --glass-border:    rgba(255,255,255,0.15);

  /* Card surfaces — recessed in dark */
  --card-bg:         #232326;
  --card-surface:    transparent;

  /* Orb colors for background pattern */
  --orb-primary:     rgba(184,115,51,0.07);
  --orb-secondary:   rgba(94,80,63,0.05);
  --orb-tertiary:    rgba(161,177,198,0.04);
}

/* ── Light theme ── */
[data-theme="light"], .light {
  --bg-primary:      #F9F7F4;
  --bg-card:         rgba(255,255,255,0.60);
  --border-color:    rgba(0,0,0,0.10);

  --text-primary:    #1C1C1E;
  --text-secondary:  rgba(28,28,30,0.78);
  --text-muted:      rgba(28,28,30,0.54);

  /* Glass layers */
  --glass-base:      rgba(255,255,255,0.70);
  --glass-elevated:  rgba(255,255,255,0.85);
  --glass-border:    rgba(0,0,0,0.10);

  /* Card surfaces — lifted in light */
  --card-bg:         rgba(255,255,255,0.72);
  --card-surface:    rgba(255,255,255,0.50);

  /* Orb colors for background pattern */
  --orb-primary:     rgba(184,115,51,0.08);
  --orb-secondary:   rgba(94,80,63,0.06);
  --orb-tertiary:    rgba(161,177,198,0.06);
}
`

/* ─── tailwind.config.ts additions ─── */
export const TAILWIND_TOKENS = {
  colors: {
    koppar:      '#B87333',
    jordbrun:    '#5E503F',
    sandbeige:   '#E5D9C7',
    oliv:        '#3A4A42',
    dimblag:     '#A1B1C6',
    kalkvit:     '#F9F7F4',
    charcoal:    '#1C1C1E',
    skogsgron:   '#6B8E6F',
    tegelrod:    '#B54A46',
    brandAmber:  '#CC8B3C',
    pillar: {
      identity:   '#B87333',
      emotional:  '#A1B1C6',
      physical:   '#6B8E6F',
      connection: '#8A7264',
      mission:    '#6E8077',
    },
  },
  fontFamily: {
    display: ['Neutraface 2 Display', 'Montserrat', 'sans-serif'],
    serif:   ['Playfair Display', 'Georgia', 'serif'],
    body:    ['Lato', 'system-ui', 'sans-serif'],
  },
}
