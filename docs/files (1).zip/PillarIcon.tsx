/**
 * PillarIcon
 * Nordic Precision Line SVG icons for the 5 CLAIM'N pillars.
 *
 * Usage:
 *   <PillarIcon pillar="identity" size={32} />
 *   <PillarIcon pillar="physical" size={80} className="opacity-15 rotate-12" />
 *
 * Design rules:
 *  - Structural strokes: stroke="currentColor" at opacity 0.07–0.22 (auto-adapts dark/light)
 *  - Pillar accent: hardcoded hex from pillar token (tested on both bg colors)
 *  - Fills: rgba at 0.08–0.15 max — "strokes define shape, fills accent focal point"
 *  - No fills except pillar dots and active zone accents
 */

import React from 'react'
import { type PillarId, getPillar } from '../tokens/pillars'

interface PillarIconProps {
  pillar: PillarId
  size?: 32 | 80
  className?: string
}

/* ─── IDENTITY & PURPOSE ─────────────────────────────────
   Foundation grid + direction vector rising from it.
   Grid = architecture substrate. Vector = purpose/direction.
──────────────────────────────────────────────────────── */
const IdentityIcon32 = ({ color }: { color: string }) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
    {/* Foundation grid */}
    <line x1="2"  y1="27" x2="30" y2="27" stroke="currentColor" strokeWidth="0.7" opacity="0.18"/>
    <line x1="4"  y1="23" x2="28" y2="23" stroke="currentColor" strokeWidth="0.6" opacity="0.12"/>
    <line x1="6"  y1="19" x2="26" y2="19" stroke="currentColor" strokeWidth="0.5" opacity="0.08"/>
    <line x1="8"  y1="19" x2="8"  y2="27" stroke="currentColor" strokeWidth="0.5" opacity="0.07"/>
    <line x1="16" y1="19" x2="16" y2="27" stroke="currentColor" strokeWidth="0.5" opacity="0.07"/>
    <line x1="24" y1="19" x2="24" y2="27" stroke="currentColor" strokeWidth="0.5" opacity="0.07"/>
    {/* Base anchor */}
    <circle cx="16" cy="27" r="2" stroke={color} strokeWidth="1.2" fill={`rgba(184,115,51,0.18)`}/>
    {/* Ghost full vector */}
    <line x1="16" y1="27" x2="16" y2="7" stroke="currentColor" strokeWidth="0.8" opacity="0.18" strokeLinecap="round"/>
    {/* Koppar direction vector */}
    <line x1="16" y1="27" x2="16" y2="8.5" stroke={color} strokeWidth="1.5" opacity="0.85" strokeLinecap="round"/>
    {/* Arrowhead */}
    <path d="M16 5.5 L14 10.5 L16 9.2 L18 10.5 Z" fill={color} opacity="0.9"/>
  </svg>
)

const IdentityIcon80 = ({ color }: { color: string }) => (
  <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
    {/* Foundation grid layers */}
    <line x1="4"  y1="70" x2="76" y2="70" stroke="currentColor" strokeWidth="0.8" opacity="0.20"/>
    <line x1="8"  y1="63" x2="72" y2="63" stroke="currentColor" strokeWidth="0.7" opacity="0.14"/>
    <line x1="12" y1="56" x2="68" y2="56" stroke="currentColor" strokeWidth="0.6" opacity="0.09"/>
    <line x1="16" y1="49" x2="64" y2="49" stroke="currentColor" strokeWidth="0.5" opacity="0.06"/>
    {/* Vertical grid at base */}
    <line x1="20" y1="56" x2="20" y2="70" stroke="currentColor" strokeWidth="0.5" opacity="0.07"/>
    <line x1="30" y1="56" x2="30" y2="70" stroke="currentColor" strokeWidth="0.5" opacity="0.07"/>
    <line x1="40" y1="56" x2="40" y2="70" stroke="currentColor" strokeWidth="0.5" opacity="0.07"/>
    <line x1="50" y1="56" x2="50" y2="70" stroke="currentColor" strokeWidth="0.5" opacity="0.07"/>
    <line x1="60" y1="56" x2="60" y2="70" stroke="currentColor" strokeWidth="0.5" opacity="0.07"/>
    {/* Ghost orientation ring */}
    <circle cx="40" cy="36" r="18" stroke="currentColor" strokeWidth="0.6" opacity="0.10"/>
    <circle cx="40" cy="36" r="10" stroke={color} strokeWidth="1.3" opacity="0.60"/>
    {/* Cardinal ticks on ring */}
    <line x1="40" y1="26" x2="40" y2="23" stroke={color} strokeWidth="1.2" opacity="0.65" strokeLinecap="round"/>
    <line x1="50" y1="36" x2="53" y2="36" stroke={color} strokeWidth="1.2" opacity="0.45" strokeLinecap="round"/>
    {/* Base anchor */}
    <circle cx="40" cy="70" r="3.5" stroke={color} strokeWidth="1.3" fill={`rgba(184,115,51,0.15)`}/>
    {/* Ghost full vector */}
    <line x1="40" y1="70" x2="40" y2="10" stroke="currentColor" strokeWidth="0.8" opacity="0.14" strokeLinecap="round"/>
    {/* Direction vector */}
    <line x1="40" y1="70" x2="40" y2="11" stroke={color} strokeWidth="1.6" opacity="0.82" strokeLinecap="round"/>
    {/* Arrowhead */}
    <path d="M40 7 L37 14 L40 12.5 L43 14 Z" fill={color} opacity="0.92"/>
  </svg>
)

/* ─── EMOTIONAL & MENTAL ─────────────────────────────────
   Chaotic input wave → conversion node → coherent output.
   Pressure in, performance out.
──────────────────────────────────────────────────────── */
const EmotionalIcon32 = ({ color }: { color: string }) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
    <line x1="2" y1="16" x2="30" y2="16" stroke="currentColor" strokeWidth="0.5" opacity="0.10"/>
    {/* Chaotic input wave */}
    <polyline
      points="2,16 4,10 5.5,21 7,9 8.5,20 10,12 12,16"
      stroke="currentColor" strokeWidth="1.2" opacity="0.42"
      fill="none" strokeLinecap="round" strokeLinejoin="round"
    />
    {/* Conversion node */}
    <circle cx="16" cy="16" r="3.2" stroke={color} strokeWidth="1.5" fill={`rgba(161,177,198,0.14)`}/>
    <circle cx="16" cy="16" r="1"   fill={color} opacity="0.80"/>
    {/* Coherent output wave */}
    <path
      d="M20,16 Q22.5,10.5 25,16 Q27.5,21.5 30,16"
      stroke={color} strokeWidth="1.5" opacity="0.88"
      fill="none" strokeLinecap="round"
    />
    {/* Directional arrow */}
    <path
      d="M13.2,13.8 L14.6,16 L13.2,18.2"
      stroke={color} strokeWidth="0.8" fill="none" opacity="0.45"
      strokeLinecap="round" strokeLinejoin="round"
    />
  </svg>
)

const EmotionalIcon80 = ({ color }: { color: string }) => (
  <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
    <line x1="4" y1="40" x2="76" y2="40" stroke="currentColor" strokeWidth="0.6" opacity="0.10"/>
    {/* Zone boundaries */}
    <rect x="4"  y="16" width="30" height="48" rx="4" stroke="currentColor" strokeWidth="0.5" opacity="0.06" fill="none"/>
    <rect x="46" y="20" width="30" height="40" rx="4" stroke={color} strokeWidth="0.5" opacity="0.12" fill={`rgba(161,177,198,0.04)`}/>
    {/* Chaotic input */}
    <polyline
      points="4,40 8,24 11.5,52 15,20 18.5,48 22,28 25.5,44 29,32 32,40"
      stroke="currentColor" strokeWidth="1.3" opacity="0.38"
      fill="none" strokeLinecap="round" strokeLinejoin="round"
    />
    <text x="18" y="68" textAnchor="middle" fontFamily="var(--font-display)" fontSize="7" fill="currentColor" opacity="0.22" letterSpacing="0.1em">PRESSURE</text>
    {/* Flow arrows */}
    <path d="M34,37 L37,40 L34,43" stroke={color} strokeWidth="1" fill="none" opacity="0.50" strokeLinecap="round" strokeLinejoin="round"/>
    {/* Conversion node */}
    <circle cx="40" cy="40" r="7" stroke={color} strokeWidth="2" fill={`rgba(161,177,198,0.12)`}/>
    <circle cx="40" cy="40" r="2.5" fill={color} opacity="0.85"/>
    {/* Flow arrows out */}
    <path d="M43,37 L46,40 L43,43" stroke={color} strokeWidth="1" fill="none" opacity="0.50" strokeLinecap="round" strokeLinejoin="round"/>
    {/* Coherent output wave */}
    <path
      d="M47,40 Q51.5,28 56,40 Q60.5,52 65,40 Q68,32 71,40 Q73,44 76,40"
      stroke={color} strokeWidth="1.7" opacity="0.90"
      fill="none" strokeLinecap="round"
    />
    {/* Subtle fill under output wave */}
    <path
      d="M47,40 Q51.5,28 56,40 Q60.5,52 65,40 Q68,32 71,40 Q73,44 76,40 L76,55 Q71,55 68,48 Q65,52 61,52 Q57,52 54,48 Q51,52 47,52 Z"
      fill={`rgba(161,177,198,0.07)`}
    />
    <text x="61" y="68" textAnchor="middle" fontFamily="var(--font-display)" fontSize="7" fill={color} opacity="0.30" letterSpacing="0.08em">OUTPUT</text>
  </svg>
)

/* ─── PHYSICAL & VITAL ───────────────────────────────────
   Ascending performance bars + trajectory arc + apex dot.
   Decades on x-axis — sustained capability, not peak fitness.
──────────────────────────────────────────────────────── */
const PhysicalIcon32 = ({ color }: { color: string }) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
    <line x1="2" y1="29" x2="30" y2="29" stroke="currentColor" strokeWidth="0.6" opacity="0.20"/>
    <rect x="2"  y="22" width="5" height="7"  rx="1.2" stroke="currentColor" strokeWidth="1.0" opacity="0.30"/>
    <rect x="9"  y="17" width="5" height="12" rx="1.2" stroke="currentColor" strokeWidth="1.1" opacity="0.45"/>
    <rect x="16" y="11" width="5" height="18" rx="1.2" stroke={color} strokeWidth="1.5"/>
    <rect x="23" y="5"  width="5" height="24" rx="1.2" stroke={color} strokeWidth="1.8" fill={`rgba(107,142,111,0.14)`}/>
    <path d="M4.5 23 Q12 15 25.5 6" stroke={color} strokeWidth="1" strokeDasharray="2 2" fill="none" opacity="0.60"/>
    <circle cx="25.5" cy="6" r="2.2" fill={color} opacity="0.85"/>
  </svg>
)

const PhysicalIcon80 = ({ color }: { color: string }) => (
  <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
    {/* Grid */}
    <line x1="4" y1="72" x2="76" y2="72" stroke="currentColor" strokeWidth="0.7" opacity="0.18"/>
    <line x1="4" y1="56" x2="76" y2="56" stroke="currentColor" strokeWidth="0.5" opacity="0.08"/>
    <line x1="4" y1="40" x2="76" y2="40" stroke="currentColor" strokeWidth="0.5" opacity="0.06"/>
    <line x1="4" y1="24" x2="76" y2="24" stroke="currentColor" strokeWidth="0.5" opacity="0.05"/>
    {/* Bars */}
    <rect x="4"  y="54" width="10" height="18" rx="2" stroke="currentColor" strokeWidth="1.0" opacity="0.28"/>
    <rect x="18" y="44" width="10" height="28" rx="2" stroke="currentColor" strokeWidth="1.1" opacity="0.40"/>
    <rect x="32" y="32" width="10" height="40" rx="2" stroke={color} strokeWidth="1.5" fill={`rgba(107,142,111,0.07)`}/>
    <rect x="46" y="20" width="10" height="52" rx="2" stroke={color} strokeWidth="1.7" fill={`rgba(107,142,111,0.10)`}/>
    <rect x="60" y="8"  width="10" height="64" rx="2" stroke={color} strokeWidth="2.0" fill={`rgba(107,142,111,0.16)`}/>
    {/* Trajectory arc */}
    <path d="M9 56 Q28 38 65 10" stroke={color} strokeWidth="1.1" strokeDasharray="2.5 2.5" fill="none" opacity="0.65"/>
    {/* Apex dot */}
    <circle cx="65" cy="10" r="4" fill={color} opacity="0.85"/>
    {/* Decade labels */}
    <text x="9"  y="78" textAnchor="middle" fontFamily="var(--font-display)" fontSize="7" fill="currentColor" opacity="0.25">30s</text>
    <text x="37" y="78" textAnchor="middle" fontFamily="var(--font-display)" fontSize="7" fill="currentColor" opacity="0.25">40s</text>
    <text x="65" y="78" textAnchor="middle" fontFamily="var(--font-display)" fontSize="7" fill={color} opacity="0.40">70s</text>
  </svg>
)

/* ─── CONNECTION & LEADERSHIP ────────────────────────────
   Dunbar rings 5·15·150 + parallel motion vectors.
   No central leader — equal-standing brotherhood.
──────────────────────────────────────────────────────── */
const ConnectionIcon32 = ({ color }: { color: string }) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
    {/* Outer ring 150 */}
    <circle cx="16" cy="15" r="13" stroke="currentColor" strokeWidth="0.7" opacity="0.14"/>
    {/* Middle ring 15 */}
    <circle cx="16" cy="15" r="9"  stroke="currentColor" strokeWidth="0.8" opacity="0.22"/>
    {/* Inner ring 5 */}
    <circle cx="16" cy="15" r="5.5" stroke={color} strokeWidth="1.5"/>
    {/* 5 dots on inner ring — pentagonal */}
    <circle cx="16"  cy="9.5"  r="1.3" fill={color} opacity="0.85"/>
    <circle cx="21.2" cy="12.8" r="1.3" fill={color} opacity="0.85"/>
    <circle cx="19.2" cy="19.2" r="1.3" fill={color} opacity="0.85"/>
    <circle cx="12.8" cy="19.2" r="1.3" fill={color} opacity="0.85"/>
    <circle cx="10.8" cy="12.8" r="1.3" fill={color} opacity="0.85"/>
    {/* 4 compass dots on outer ring */}
    <circle cx="16" cy="6"  r="1" fill="currentColor" opacity="0.20"/>
    <circle cx="25" cy="15" r="1" fill="currentColor" opacity="0.20"/>
    <circle cx="7"  cy="15" r="1" fill="currentColor" opacity="0.20"/>
    {/* Parallel motion vectors — shoulder-to-shoulder */}
    <line x1="5"  y1="28.5" x2="11" y2="28.5" stroke="currentColor" strokeWidth="1.0" opacity="0.30" strokeLinecap="round"/>
    <path d="M10 26.5 L12 28.5 L10 30.5" stroke="currentColor" strokeWidth="1" fill="none" opacity="0.30" strokeLinecap="round" strokeLinejoin="round"/>
    <line x1="15" y1="28.5" x2="21" y2="28.5" stroke="currentColor" strokeWidth="1.0" opacity="0.30" strokeLinecap="round"/>
    <path d="M20 26.5 L22 28.5 L20 30.5" stroke="currentColor" strokeWidth="1" fill="none" opacity="0.30" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
)

const ConnectionIcon80 = ({ color }: { color: string }) => (
  <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
    {/* Outer ring 150 */}
    <circle cx="40" cy="38" r="32" stroke="currentColor" strokeWidth="0.6" opacity="0.10"/>
    <circle cx="40" cy="6"  r="1.5" fill="currentColor" opacity="0.14"/>
    <circle cx="72" cy="38" r="1.5" fill="currentColor" opacity="0.14"/>
    <circle cx="40" cy="70" r="1.5" fill="currentColor" opacity="0.14"/>
    <circle cx="8"  cy="38" r="1.5" fill="currentColor" opacity="0.14"/>
    {/* Middle ring 15 */}
    <circle cx="40" cy="38" r="21" stroke="currentColor" strokeWidth="0.9" opacity="0.22"/>
    <circle cx="40"    cy="17"    r="2" fill="currentColor" opacity="0.22"/>
    <circle cx="54.8"  cy="23.2"  r="2" fill="currentColor" opacity="0.22"/>
    <circle cx="61"    cy="38"    r="2" fill="currentColor" opacity="0.22"/>
    <circle cx="54.8"  cy="52.8"  r="2" fill="currentColor" opacity="0.22"/>
    <circle cx="40"    cy="59"    r="2" fill="currentColor" opacity="0.22"/>
    <circle cx="25.2"  cy="52.8"  r="2" fill="currentColor" opacity="0.22"/>
    <circle cx="19"    cy="38"    r="2" fill="currentColor" opacity="0.22"/>
    <circle cx="25.2"  cy="23.2"  r="2" fill="currentColor" opacity="0.22"/>
    {/* Inner ring 5 */}
    <circle cx="40" cy="38" r="11" stroke={color} strokeWidth="2" fill={`rgba(138,114,100,0.07)`}/>
    {/* 5 dots — pentagonal */}
    <circle cx="40"   cy="27"    r="2.5" fill={color} opacity="0.88"/>
    <circle cx="50.5" cy="32.2"  r="2.5" fill={color} opacity="0.88"/>
    <circle cx="46.4" cy="44.7"  r="2.5" fill={color} opacity="0.88"/>
    <circle cx="33.6" cy="44.7"  r="2.5" fill={color} opacity="0.88"/>
    <circle cx="29.5" cy="32.2"  r="2.5" fill={color} opacity="0.88"/>
    {/* Parallel motion vectors */}
    <line x1="16" y1="74" x2="30" y2="74" stroke="currentColor" strokeWidth="1.2" opacity="0.28" strokeLinecap="round"/>
    <path d="M28 71 L31 74 L28 77" stroke="currentColor" strokeWidth="1.2" fill="none" opacity="0.28" strokeLinecap="round" strokeLinejoin="round"/>
    <line x1="36" y1="74" x2="50" y2="74" stroke="currentColor" strokeWidth="1.2" opacity="0.28" strokeLinecap="round"/>
    <path d="M48 71 L51 74 L48 77" stroke="currentColor" strokeWidth="1.2" fill="none" opacity="0.28" strokeLinecap="round" strokeLinejoin="round"/>
    <line x1="56" y1="74" x2="64" y2="74" stroke="currentColor" strokeWidth="1.2" opacity="0.20" strokeLinecap="round"/>
    {/* Layer labels */}
    <text x="40" y="16" textAnchor="middle" fontFamily="var(--font-display)" fontSize="6" fill={color} opacity="0.35">5</text>
    <text x="62" y="39" textAnchor="middle" fontFamily="var(--font-display)" fontSize="6" fill="currentColor" opacity="0.22">15</text>
    <text x="73" y="39" textAnchor="middle" fontFamily="var(--font-display)" fontSize="6" fill="currentColor" opacity="0.14">150</text>
  </svg>
)

/* ─── MISSION & MASTERY ──────────────────────────────────
   Flow zone diagonal band — challenge·skill axes.
   Csikszentmihályi: position dot inside the flow band.
──────────────────────────────────────────────────────── */
const MissionIcon32 = ({ color }: { color: string }) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
    {/* Ghost axes */}
    <line x1="4" y1="28" x2="28" y2="28" stroke="currentColor" strokeWidth="0.7" opacity="0.18" strokeLinecap="round"/>
    <line x1="4" y1="28" x2="4"  y2="4"  stroke="currentColor" strokeWidth="0.7" opacity="0.18" strokeLinecap="round"/>
    {/* Axis arrowheads */}
    <path d="M27 25.5 L29 28 L27 30.5" stroke="currentColor" strokeWidth="0.7" fill="none" opacity="0.18" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M1.5 5.5 L4 3.5 L6.5 5.5" stroke="currentColor" strokeWidth="0.7" fill="none" opacity="0.18" strokeLinecap="round" strokeLinejoin="round"/>
    {/* Flow zone band */}
    <line x1="6"  y1="26" x2="26" y2="7"  stroke={color} strokeWidth="1.3" opacity="0.65" strokeLinecap="round"/>
    <line x1="10" y1="28" x2="30" y2="10" stroke={color} strokeWidth="1.3" opacity="0.35" strokeLinecap="round"/>
    {/* Flow zone fill */}
    <polygon points="6,26 10,28 30,10 26,7" fill={`rgba(110,128,119,0.13)`}/>
    {/* Trajectory to dot */}
    <path d="M6,26 Q12,20 17,14" stroke={color} strokeWidth="1" fill="none" opacity="0.50" strokeDasharray="1.5 1.5" strokeLinecap="round"/>
    {/* Position dot — inside flow zone */}
    <circle cx="17" cy="14" r="2.5" fill={color} opacity="0.90"/>
    {/* Axis labels */}
    <text x="30" y="31" fontFamily="var(--font-display)" fontSize="5.5" fill="currentColor" opacity="0.28">C</text>
    <text x="2"  y="5"  fontFamily="var(--font-display)" fontSize="5.5" fill="currentColor" opacity="0.28">S</text>
  </svg>
)

const MissionIcon80 = ({ color }: { color: string }) => (
  <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
    {/* Ghost axes */}
    <line x1="8" y1="72" x2="74" y2="72" stroke="currentColor" strokeWidth="0.7" opacity="0.18" strokeLinecap="round"/>
    <line x1="8" y1="72" x2="8"  y2="6"  stroke="currentColor" strokeWidth="0.7" opacity="0.18" strokeLinecap="round"/>
    {/* Axis arrowheads */}
    <path d="M71 69 L74 72 L71 75" stroke="currentColor" strokeWidth="0.8" fill="none" opacity="0.18" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M5 9 L8 6 L11 9"    stroke="currentColor" strokeWidth="0.8" fill="none" opacity="0.18" strokeLinecap="round" strokeLinejoin="round"/>
    {/* Zone labels */}
    <text x="14" y="22" fontFamily="var(--font-display)" fontSize="7" fill="currentColor" opacity="0.16" letterSpacing="0.05em">ANXIETY</text>
    <text x="42" y="68" fontFamily="var(--font-display)" fontSize="7" fill="currentColor" opacity="0.16" letterSpacing="0.05em">BOREDOM</text>
    {/* Flow zone boundaries */}
    <line x1="10" y1="62" x2="70" y2="12" stroke={color} strokeWidth="1.5" opacity="0.70" strokeLinecap="round"/>
    <line x1="18" y1="72" x2="76" y2="22" stroke={color} strokeWidth="1.5" opacity="0.38" strokeLinecap="round"/>
    {/* Flow zone fill */}
    <polygon points="10,62 18,72 76,22 70,12" fill={`rgba(110,128,119,0.12)`}/>
    {/* Reference line inside zone */}
    <line x1="20" y1="60" x2="60" y2="28" stroke={color} strokeWidth="0.6" opacity="0.18" strokeDasharray="2 3"/>
    {/* Trajectory to dot */}
    <path d="M16,68 Q28,56 40,42" stroke={color} strokeWidth="1.1" fill="none" opacity="0.55" strokeDasharray="2 2" strokeLinecap="round"/>
    {/* Position dot — inside flow zone */}
    <circle cx="40" cy="42" r="5" fill={color} opacity="0.88"/>
    <circle cx="40" cy="42" r="2" fill="rgba(249,247,244,0.60)"/>
    {/* FLOW label */}
    <text x="54" y="36" fontFamily="var(--font-display)" fontWeight="bold" fontSize="7" fill={color} opacity="0.45" letterSpacing="0.10em">FLOW</text>
    {/* Axis labels */}
    <text x="76" y="76" textAnchor="middle" fontFamily="var(--font-display)" fontSize="7" fill="currentColor" opacity="0.30">C</text>
    <text x="6"  y="8"  textAnchor="middle" fontFamily="var(--font-display)" fontSize="7" fill="currentColor" opacity="0.30">S</text>
  </svg>
)

/* ─── ICON MAP ─── */
const ICONS_32: Record<PillarId, (props: { color: string }) => React.ReactElement> = {
  identity:   IdentityIcon32,
  emotional:  EmotionalIcon32,
  physical:   PhysicalIcon32,
  connection: ConnectionIcon32,
  mission:    MissionIcon32,
}

const ICONS_80: Record<PillarId, (props: { color: string }) => React.ReactElement> = {
  identity:   IdentityIcon80,
  emotional:  EmotionalIcon80,
  physical:   PhysicalIcon80,
  connection: ConnectionIcon80,
  mission:    MissionIcon80,
}

/* ─── COMPONENT ─── */
export const PillarIcon: React.FC<PillarIconProps> = ({
  pillar,
  size = 32,
  className = '',
}) => {
  const token = getPillar(pillar)
  const IconComponent = size === 80 ? ICONS_80[pillar] : ICONS_32[pillar]

  return (
    <span className={className} style={{ display: 'inline-flex', flexShrink: 0 }}>
      <IconComponent color={token.color} />
    </span>
  )
}

export default PillarIcon
